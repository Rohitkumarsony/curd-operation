from django.contrib import admin
from django.urls import path
from .import views
from .views import delete_user

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'), 
    path('success/', views.success, name='success'), 
    path('delete_user/<int:user_id>/',views.delete_user, name='delete_user'),
    path('update_user/<int:user_id>/', views.update_user, name='update_user'),
]