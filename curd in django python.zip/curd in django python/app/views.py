from django.shortcuts import render, redirect
from django.shortcuts import get_object_or_404
from django.template import Template
from django.template import loader
from django.http import HttpResponse
from .models import User  
from .forms import UserForm  

def index(request):
    if request.method == 'POST':
        username = request.POST.get('fname', '')
        email = request.POST.get('email', '')
        password = request.POST.get('password', '')
        phone = request.POST.get('phone', '')

        if User.objects.filter(email=email).exists() or User.objects.filter(phone=phone).exists():
            return render(request, 'index.html', {'error_message': 'Email or phone number already exists.'})

        user = User(fname=username, email=email, password=password, phone=phone)
        user.save()

        return redirect('success')

    return render(request, 'index.html')



def success(request):
    mydata=User.objects.all().values()
    template=loader.get_template('success.html')
    context={
        'mymembers': mydata,
    }
    
    return HttpResponse(template.render(context,request))
    
def delete_user(request, user_id):
    user_to_delete = get_object_or_404(User, pk=user_id)
    user_to_delete.delete()
    return redirect('success')



def update_user(request, user_id):
    user = get_object_or_404(User, pk=user_id)
    
    if request.method == 'POST':
        form = UserForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
            return redirect('success')
    else:
        form = UserForm(instance=user)

    return render(request, 'update_user.html', {'form': form, 'user_id': user_id})


    
    
