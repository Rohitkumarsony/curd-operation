<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "submits";

try {
    $data = json_decode(file_get_contents("php://input"));

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    if (isset($data->id)) {
        $id = $data->id;

        if (isset($data->address1, $data->address2, $data->country, $data->state, $data->city)) {
            $address1 = $data->address1;
            $address2 = $data->address2;
            $country = $data->country;
            $state = $data->state;
            $city = $data->city;

            $sqlAddress = "UPDATE location SET address1 = ?, address2 = ?, country = ?, state = ?, city = ? WHERE user_id = ?";
            $stmtAddress = $conn->prepare($sqlAddress);

            if ($stmtAddress === false) {
                throw new Exception("Address: Prepare failed: " . $conn->error);
            }

            $stmtAddress->bind_param("sssssi", $address1, $address2, $country, $state, $city, $id);

            if ($stmtAddress->execute()) {
                // Address details updated successfully
            } else {
                throw new Exception("Address: Error updating address details: " . $stmtAddress->error);
            }

            $stmtAddress->close();
        }

        if (isset($data->name, $data->email, $data->phone)) {
            $name = $data->name;
            $email = $data->email;
            $phone = $data->phone;

            $sqlUser = "UPDATE users SET name = ?, email = ?, phone = ? WHERE id = ?";
            $stmtUser = $conn->prepare($sqlUser);

            if ($stmtUser === false) {
                throw new Exception("User: Prepare failed: " . $conn->error);
            }

            $stmtUser->bind_param("sssi", $name, $email, $phone, $id);

            if ($stmtUser->execute()) {
                $response = 'User updated successfully';
            } else {
                throw new Exception("User: Error updating user: " . $stmtUser->error);
            }

            $stmtUser->close();
        }
    } else {
        throw new Exception("Missing required data.");
    }
} catch (Exception $e) {
    echo "An error occurred: " . $e->getMessage();
} finally {
    if (isset($conn)) {
        $conn->close();
    }
}
?>

