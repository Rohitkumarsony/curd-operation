<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "submits";

try {
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    if (isset($_POST["id"])) {
        $id = $_POST["id"];


        $sqlLocation = "DELETE FROM location WHERE user_id = $id";

        if ($conn->query($sqlLocation) === TRUE) {
            // Second, delete from the "users" table
            $sqlUsers = "DELETE FROM users WHERE id = $id";

            if ($conn->query($sqlUsers) === TRUE) {
                echo "Data deleted successfully!";
            } else {
                throw new Exception("Error deleting user: " . $conn->error);
            }
        } else {
            throw new Exception("Error deleting address details: " . $conn->error);
        }
    } else {
        throw new Exception("Missing required data.");
    }
} catch (Exception $e) {
    echo "An error occurred: " . $e->getMessage();
} finally {
    if (isset($conn)) {
        $conn->close();
    }
}
?>

