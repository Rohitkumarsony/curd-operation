<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "submits";

try {
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    $json_data = file_get_contents("php://input");
    $data = json_decode($json_data);

    if (!empty($data) && isset($data->name) && isset($data->email) && isset($data->phone)) {
        $name = $data->name;
        $email = $data->email;
        $phone = $data->phone;


        $check = "SELECT * FROM users WHERE email=?";
        $stmtCheck = $conn->prepare($check);

        if ($stmtCheck === false) {
            throw new Exception("Prepare failed: " . $conn->error);
        }

        $stmtCheck->bind_param("s", $email);
        $stmtCheck->execute();
        $result = $stmtCheck->get_result();

        if ($result->num_rows > 0) {
        

            $response = ("Email already exists. Please try another email address.");
            
        } else {

            $sql = "INSERT INTO users (name, email, phone) VALUES (?, ?, ?)";
            $stmtUser = $conn->prepare($sql);

            if ($stmtUser === false) {
                throw new Exception("Prepare failed: " . $conn->error);
            }

            $stmtUser->bind_param("sss", $name, $email, $phone);

            if ($stmtUser->execute()) {
                // Get the last inserted user_id
                $user_id = $stmtUser->insert_id;

                if (isset($data->address1) && isset($data->address2) && isset($data->country) && isset($data->state) && isset($data->city)) {
                    $address1 = $data->address1;
                    $address2 = $data->address2;
                    $country = $data->country;
                    $state = $data->state;
                    $city = $data->city;


                    $sql = "INSERT INTO location (user_id, address1, address2, country, state, city) VALUES (?, ?, ?, ?, ?, ?)";
                    $stmtAddress = $conn->prepare($sql);

                    if ($stmtAddress === false) {
                        throw new Exception("Prepare failed: " . $conn->error);
                    }

                    $stmtAddress->bind_param("isssss", $user_id, $address1, $address2, $country, $state, $city);

                    if ($stmtAddress->execute()) {
                        $response = ("Data submitted successfully");
                    } else {
                        $response = array("status" => "error", "message" => "Error inserting address data: " . $stmtAddress->error);
                    }
                } else {
                    $response = array("status" => "success", "message" => "User data inserted successfully!");
                }
            } else {
                $response = array("status" => "error", "message" => "Error inserting user data: " . $stmtUser->error);
            }
        }
    } else {
        throw new Exception("Invalid or missing JSON data.");
    }
} catch (Exception $e) {
    $response = array("status" => "error", "message" => $e->getMessage());
} finally {
    if (isset($conn)) {
        $conn->close();
    }
}

echo json_encode($response);
?>

