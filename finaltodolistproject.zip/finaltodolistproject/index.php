<!DOCTYPE html>
<html>
<head>
    <title>my Application</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <style>
    
    * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .container {
            min-height: 550px;
            max-width: 700px;
            background-color: lightgray;
            border: 1px solid red;
            display: flex;
            text-align: center;
            justify-content: center;
            align-items: center;
            margin: 0 auto;
            background: space-between;
            margin-top: 10px;
        }

        table,
        thead,
        tr,
        th,
        td {
            border: 1px solid black;
            border-collapse: collapse;
            padding: 10px;
            text-align:center;
            align-items:center;
            
            
        }

        input[type="text"],
        input[type="email"],
        input[type="text"] {
            font-size: 17px;
            padding: 10px;
            border: 2px solid #c0c0c0;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            background-color: #f7f7f7;
            color: #333;
        }

        input[type="text"]:hover,
        input[type="email"]:hover,
       
        input[type="text"]:hover {
            border-color: #999;
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
       
        input[type="text"]:focus {
            border-color: #007bff;
            box-shadow: 0 0 10px rgba(0, 123, 255, 0.5);
            outline: none;
        }

        button[type="submit"] {
            font-size: 1em;
            height: 3%;
            width: 28%;
            padding: 10px;
            color: #fff;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button[type="submit"]:hover,
        button[type="submit"]:focus {
            background-color: #0056b3;
        }

        button[type="submit"]:active {
            background-color: #003e80;
        }
        #error-message {
       color: red;
       font-size: 17px;
      margin-top: 10px;
}
.hello{
display:flex;
margin:0 auto;
gap:10px;
font-size: 15px;
}
#country,#state{
width:120px;
height:30px;
}
#city{
height:30px;
width:120px;
}
    
    </style>
    
    
</head>
<body>
   
   
<div class="container">
    <form action="#" method="post" onsubmit="return validateForm()" id="userForm">
        <label for="name">Name</label>
        <input type="text" id="name" name="name" autocomplete="off" placeholder="enter your name..."><br><br>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" autocomplete="off" placeholder="enter your Eame..."><br><br>

        <label for="phone">Phone</label>
        <input type="text" id="phone" name="phone" autocomplete="off" placeholder="enter your Phone Number..."><br><br>
        
         <label for="address1">Address1</label>
        <input type="text" id="address1" name="address1" autocomplete="off" placeholder="enter your Parmanent Address..."><br><br>
        
         <label for="address2">Address2</label>
        <input type="text" id="address2" name="address2" autocomplete="off" placeholder="enter your Present Address..."><br><br>
        
        
        <div class="hello">
    <label for="country">Country</label>
    <select id="country">
        <option value="">Select country</option>
    </select><br><br>

    <label for="state">State</label>
    <select id="state">
        <option value="" attr="">Select state</option>
    </select><br><br>
      <label for="city">City</label>
    <select id="city">
        <option value="">Select City</option>
    </select><br><br>
   
</div><br><br>

        
        
        <input type="hidden" id="userId" name="userId">
         <div id="response-message"></div>
        <button type="submit" class="btn btn-primary" id="insert" name="submit">Submit</button>
        <button type="submit" class="btn btn-primary" id="update" style="display:none;">Update</button>

        <div id="error-message" style="display: none;"></div>
    </form>
</div>

<h2>Users</h2>
<table id="userTable">
    <thead>
    <tr> 
       
        <th style="font-size:28px;">Name</th>
        <th style="font-size:28px;">Email</th>
        <th style="font-size:28px;">Phone</th>
        <th style="font-size:28px;">Address1</th>
        <th style="font-size:28px;">Address2</th>
        <th style="font-size:28px;">Country</th>
        <th style="font-size:28px;">State</th>
        <th style="font-size:28px;">City</th>
         <th style="font-size:28px;" colspan=2" >Actions</th>
        
    </tr>
    </thead>
    <tbody id="storedata"></tbody>
</table>
<!-- Include SweetAlert2 from CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>

        $(document).ready(function(){
            $.ajax({
                url:"countries.json",
                method:"get",
                dataType:"json",
                success:function(data){
                var countries="";
                for(var x in data["countries"])
                {
          countries+="<option attr ='"+data["countries"][x]["name"]+ "'value ='"+data["countries"][x]["sortname"]+"'data-sid='"+data["countries"][x]["id"]+"' >"+data["countries"][x]["sortname"]+"-"+data["countries"][x]["name"] +"</option>";
                    }
                    $("#country").html(countries);
                }
            })
            $("#country").on("change",function(){

                changestate();
            });

            $("#state").on("change",function(){

                changecity();
            });

            function changestate()
        {
            var countrycode = $("#country option:selected").attr("data-sid");
                $.ajax({
                    url:"states.json",
                    method:"GET",
                    dataType:"json",
                    success:function(data)
                    {
                        var states="";
                        for(var x in data["states"])
                        {                  

                            if(countrycode==data["states"][x]["country_id"])

                            {

                                states+="<option value ='"+data["states"][x]["name"]+"'data-sid='"+data["states"][x]["id"]+"'>"+data["states"][x]["name"] +"</option>";
                            }

                        }

                        $("#state").html(states);

                    }

                })
        }

        function changecity()

        {
            var statecode = $("#state option:selected").attr("data-sid");
            $.ajax({

                   url:"cities.json",
                    method:"GET",
                    dataType:"json",
                    success:function(data)
                    {
                        var cities=""
                        for(var x in data["cities"])
                        {
                            if(statecode==data["cities"][x]["state_id"])

                            {

                                cities+="<option value ='"+data["cities"][x]["name"]+"'data-sid='"+data["cities"][x]["id"]+"'>"+data["cities"][x]["name"] +"</option>";
                            }

                        }

                        $("#city").html(cities);

                    }

                })
        }

        })

 
    function validateForm() {
        var nameInput = document.getElementById("name").value;
        var emailInput = document.getElementById("email").value;
        var phoneInput = document.getElementById("phone").value;
        var address1Input = document.getElementById("address1").value;
        var address2Input = document.getElementById("address2").value;
        var country = document.getElementById("country").value;
        var state = document.getElementById("state").value;
        var city = document.getElementById("city").value;

        

        var namePattern = /^[a-zA-Z\s@]*$/;

        if (nameInput === "" || emailInput === "" || phoneInput === "") {
            $("#error-message").text("Please fill in all the required fields.").show();
            return false;
        } else {

            $("#error-message").hide();
        }

        if (!namePattern.test(nameInput) || nameInput == "") {
            alert("Name should consist of letters");
            return false;
        }

        if (!emailInput.includes('@')) {
            alert("Please enter a valid email address");
            return false;
        }

        if (isNaN(phoneInput) || phoneInput.length !== 10) {
            alert("Phone number should be 10 digits.");
            return false;
        }
        if (address1Input === "") {
       alert("Address is not empty");
       return false;
}
     if (address2Input === "") {
       alert("Address is not empty");
       return false;
}

     if (country === "") {
       alert("select county name ");
       return false;
}

     if (state === "") {
       alert("Select State name");
       return false;
}
     if (city === "") {
       alert("Slect city name");
       return false;
}



        return true;
    }
    
    function fetchData() {
    $.ajax({
        type: "POST",
        url: "fetch.php",
        dataType: "json",
        success: function (data) {
            if (data && data.length > 0) {
                var tableHtml = "";
                for (var i = 0; i < data.length; i++) {
                    var row = data[i];
                    tableHtml += "<tr>";
                    tableHtml += "<td>" + row.name + "</td>";
                    tableHtml += "<td>" + row.email + "</td>";
                    tableHtml += "<td>" + row.phone + "</td>";
                    tableHtml += "<td>" + row.address1 + "</td>";
                    tableHtml += "<td>" + row.address2 + "</td>";
                    tableHtml += "<td>" + row.country + "</td>";
                    tableHtml += "<td>" + row.state + "</td>";
                    tableHtml += "<td>" + row.city + "</td>";
                    tableHtml += "<td><button onclick='deleteRow(" + row.user_id + ")'>Delete</button></td>";
                    tableHtml += "<td><button onclick='updateUser(" + row.user_id + ", \"" + row.name + "\", \"" + row.email + "\", \"" + row.phone + "\", \"" + row.address1 + "\", \"" + row.address2 + "\", \"" + row.country + "\", \"" + row.state + "\", \"" + row.city + "\")'>Edit</button></td>";
                    tableHtml += "</tr>";
                    
                }
                $("#userTable tbody").html(tableHtml);
            } else {
                $("#userTable tbody").html("<tr><td colspan='9'>No data found</td></tr>");
            }
        },
        error: function () {
            $("#userTable tbody").html("<tr><td colspan='9'>Error fetching data</td></tr>");
        }
    });
}


fetchData();

     // Function to insert a new user
    function insertUser() {
    var userData = {
        name: $("#name").val(),
        email: $("#email").val(),
        phone: $("#phone").val(),
        address1: $("#address1").val(),
        address2: $("#address2").val(),
        country: $("#country").val(),
        state: $("#state").val(),
        city: $("#city").val()
    };

    $.ajax({
        type: "POST",
        url: "insert.php",
        contentType: "application/json; charset=utf-8",
        data: JSON.stringify(userData),
        success: function (response) {
            console.log(response);

            if (response === "Email already exists. Please try another email address") {

                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: response
                });
            } else {
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: response
                });

                fetchData();
                $("#userForm")[0].reset();
            }
        }
    });
}

// delete data function
   function deleteRow(user_id) {
    Swal.fire({
        title: 'Are you sure?',
        text: 'you want to delete!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'No, cancel',
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            // User confirmed the delete action
            $.ajax({
                type: 'POST',
                url: 'delete.php',
                data: {
                    id: user_id
                },
                success: function (response) {
                    console.log(response);
                    fetchData();
                    $("#userForm")[0].reset();
                    $("#userId").val("");
                },
               
            });
        } 
    });
}



        // Function to update a user
    function updateUserAndSubmit(user_id) {
    var userData = {
        id: user_id,
        name: $("#name").val(),
        email: $("#email").val(),
        phone: $("#phone").val(),
        address1: $("#address1").val(),
        address2: $("#address2").val(),
        country: $("#country").val(),
        state: $("#state").val(),
        city: $("#city").val()
    };

    Swal.fire({
        title: 'Are you sure?',
        text: 'You want to update the user data?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, update it!',
        cancelButtonText: 'No, cancel',
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                type: "POST",
                url: "update.php",
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify(userData),
                success: function (response) {
                    console.log(response);
                     
                    fetchData();
                    $("#userForm")[0].reset();
                    $("#userId").val("");
                },
               
            });
        }
    });
}


        // Show the data in input fields for editing
        function updateUser(id, name, email, phone,address1,address2,country,state,city) {
            var row = $("tr[data-row-id='" + id + "']");
            row.find(".name").text(name);
            row.find(".email").text(email);
            row.find(".phone").text(phone);
            row.find(".address1").text(address1);
            row.find(".address2").text(address2);
            row.find(".country").text(country);
            row.find(".state").text(state);
            row.find(".city").text(city);
            $("#userId").val(id);
            $("#name").val(name);
            $("#email").val(email);
            $("#phone").val(phone);
            $("#address1").val(address1);
             $("#address2").val(address2);
            $("#country").val(country); 
            $("#state").val(state);
             $("#city").val(city);
             



            // Change the submit button text to "Update & Save"
            $("#insert").hide();
            $("#update").show();
            
        }

        // Event handler for the "Add User" button
        $("#insert").click(function (event) {
            event.preventDefault();
            if (validateForm()) {
                var userId = $("#userId").val();
                if (!userId) {
                    insertUser();
                } else {
                    updateUserAndSubmit(userId);
                }
            }
        });

        // Event handler for the "Update User" button
        $("#update").click(function (event) {
            event.preventDefault();
            var userId = $("#userId").val();
            if (validateForm() && userId) {
                updateUserAndSubmit(userId);
            }
        });
        
 

    
</script>
</body>
</html>


