<?php
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "submits";


$conn = mysqli_connect($hostname, $username, $password, $dbname);


if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$createDatabaseQuery = "CREATE DATABASE IF NOT EXISTS $dbname";

if (!mysqli_query($conn, $createDatabaseQuery)) {
    die("Database creation failed: " . mysqli_error($conn));
}


mysqli_select_db($conn, $dbname);


$createTableQuery1 = "CREATE TABLE IF NOT EXISTS users (
    id INT primary key AUTO_INCREMENT,
    name VARCHAR(20) NOT NULL,
    email TEXT NOT NULL,  -- Changed 'emails' to 'email' for consistency
    phone TEXT NOT NULL
)";

if (!mysqli_query($conn, $createTableQuery1)) {
    die("Table 'users' creation failed: " . mysqli_error($conn));
}


$createTableQuery2 = "CREATE TABLE IF NOT EXISTS location (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,  
    address1 VARCHAR(200) NOT NULL,
    address2 VARCHAR(200) NOT NULL,
    country TEXT NOT NULL,
    state TEXT NOT NULL,
    city TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
)";

if (!mysqli_query($conn, $createTableQuery2)) {
    die("Table 'location' creation failed: " . mysqli_error($conn));
}

echo "Tables created successfully";

// Close the database connection
mysqli_close($conn);
?>

