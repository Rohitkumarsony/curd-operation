<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "submits";

try {
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM users INNER JOIN location ON users.id = location.user_id";

    $result = $conn->query($sql);

    if ($result === false) {
        throw new Exception("Error executing the query: " . $conn->error);
    }

    $data = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }

    header('Content-Type: application/json');
    echo json_encode($data);
} catch (Exception $e) {
    echo json_encode(array('error' => 'An error occurred: ' . $e->getMessage()));
} finally {
    if (isset($conn)) {
        $conn->close();
    }
}
?>

