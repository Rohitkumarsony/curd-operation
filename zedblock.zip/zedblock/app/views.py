from django.shortcuts import render, redirect
from django.shortcuts import get_object_or_404
from django.template import Template
from django.template import loader
from django.http import HttpResponse
from .models import Blog


def add_user(request):
    if request.method == 'POST':
        title = request.POST.get('title', '')
        content = request.POST.get('content', '')
        user = Blog(title=title, content=content)
        user.save()

        return redirect('success')

def index(request):
    return render(request, 'index.html')

def success(request):
    mydata=Blog.objects.all().values()
    template=loader.get_template('success.html')
    context={
        'mymembers': mydata,
    }
    return HttpResponse(template.render(context,request))


def data(request):
    mydata=Blog.objects.all().values()
    template=loader.get_template('data.html')
    context={
        'mymembers': mydata,
    }
    return HttpResponse(template.render(context,request))
    

    
def delete_user(request, user_id):
    user_to_delete = get_object_or_404(Blog, pk=user_id)
    user_to_delete.delete()
    return redirect('success')




