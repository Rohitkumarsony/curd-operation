from django.urls import path
from .import views


urlpatterns = [
    path('',views.success,name='success'),
    path('add_user/',views.add_user,name='add_user'),
    path('data/',views.data,name='data'),
    path('index/',views.index,name='index'),
    path('delete_user/<int:user_id>/',views.delete_user, name='delete_user'),
]

